﻿#include <QApplication>
#include <QWidget>
#include <QTextEdit>
#include <QScrollArea>
#include <QPushButton>
#include <QMessageBox>
#include <QFileDialog>
#include <QVBoxLayout>
#include "include/readFile.h"
#include "include/scanner.h"

#pragma execution_character_set("utf-8")

class MyWidget : public QWidget
{
public:
    MyWidget(QWidget *parent = nullptr) : QWidget(parent)
    {
        // 设置窗口标题
        setWindowTitle("C++单词拼装分类器");
        resize(720,540);

        // 创建一个按钮，并设置按钮文本
        QPushButton *button = new QPushButton("选择文件", this);

        QVBoxLayout *layout = new QVBoxLayout(this);

        // 连接按钮的点击事件到槽函数
        connect(button, &QPushButton::clicked, this, &MyWidget::openFile);

        textEdit = new QTextEdit;
        textEdit->setPlainText(message);
        textEdit->setReadOnly(true);

        // 创建滚动区域
        QScrollArea *scrollArea = new QScrollArea;
        scrollArea->setWidgetResizable(true); // 让滚动区域自适应部件大小

        // 设置滚动区域的部件大小为窗口大小减去按钮大小
        scrollArea->setFixedSize(720, 540 - button->height());

        // 将文本编辑器设置为滚动区域的部件
        scrollArea->setWidget(textEdit);

        layout->addWidget(button);
        layout->addWidget(scrollArea);
    }


private slots:
    // 槽函数，用于打开文件对话框并获取所选文件的路径
    void openFile()
    {
        // 创建文件对话框对象
        QString filePath = QFileDialog::getOpenFileName(this, "选择文件", "/path/to/default/directory", "All Files (*)");
        filename = filePath.toStdString();
        if (filename == "")
        {
            QMessageBox::critical(this, "提醒", "未选择文件！\n");
        }else{
            processFile();
        }
    }

private:
    QTextEdit *textEdit;
    std::string filename;
    QString message;
    // 点击按钮后显示消息框
    void processFile()
    {
        vector <pair<string,TOKEN>> *result = new vector <pair<string,TOKEN>>();
        ERROR the_error = NoError;
        for(auto i: readFile(filename,this)){
            the_error = readLine(i,*result);
            if(the_error != NoError){
                QMessageBox::critical(this, "错误", "处理文件时出现错误:\n"+getError(the_error)+"\n");
                return; // 返回以避免继续处理文件
            }
        }

        message = intoQstring(*result);
        delete result;
        textEdit->setPlainText(message);
        textEdit->adjustSize();
        textEdit->repaint();
    }
};

int main(int argc, char *argv[])
{

    // 创建Qt应用程序对象
    QApplication app(argc, argv);

    // 创建自定义窗口对象
    MyWidget window;

    // 显示窗口
    window.show();

    // 运行应用程序事件循环
    return app.exec();
}
